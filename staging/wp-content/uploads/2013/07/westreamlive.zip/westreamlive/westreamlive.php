<?php
	/*
Plugin Name: WeStreamLive
Plugin URI:
Description: Plug your live stream from twitch.tv or youtube to your wordpress!
Version: .1
Author: AnyTv
Author URI: 
License:
*/
/*  Copyright 2013  OpenKit 

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


//add to settings
    add_action('admin_menu', 'westreamlive_admin_actions');

    function westreamlive_admin_actions(){
    	add_options_page('westreamlive','westreamlive','manage_options', __FILE__, 'westreamlive_admin');

    }


    function westreamlive_admin(){
    	?>
    	<div class="wrap">
    		<h4>
    			We stream here on WESTREAM!
    		</h4>
    	</div>
    	<p>
            Copy-paste the shortcode to your page/post.
        </p>
        <div>
            <form method='POST' action='<?php echo $PHP_SELF;?>'>
                <table>
                    <tr>
                        <td>
                            Choose a player: 
                        </td>
                        <td>
                            <select name="chplayer">
                                <option value='twitch'>Twitch</option>
                                <option value='youtube'>Youtube</option>
                            </select>
                        </td>
                    </tr> 
                <tr>
                    <td>
                        <input type='submit' value='GENERATE'>
                    </td>
                </tr>
            </table>
            
            
        </div>
        <?php
       $play = $_POST['chplayer'];
        if($play!=NULL){
            echo "shortcode:<br>";
            echo "<textarea id=\"forshortcode\" rows=\"4\" cols=\"75\">";
            echo "[westream ";
            echo "playername='".$play."' ]";;
            echo "</textarea>";
        }
    }

    function westreamplug( $atts ) {
      /** @var $stream_url LSB_Stream_Summary */
      extract( shortcode_atts( array(
          'playername' =>	'$atts',	
          ), $atts ) );

      //database
      global $wpdb;
      $players=array();
      $ign=array();
      $i=0;
      $result = $wpdb->get_results("SELECT * from topplayerlist WHERE streamURI LIKE '%twitch%'");
      foreach ($result as $key) {
                    if($key->approved==1){
                        if($key->streaming==1){
                            $players[$i]=$key->playerIGN;
                            $ign[$i]=strtolower($players[$i]);
                            $i++;
                        }
                    }
        }

      if($playername=='twitch'){
        $html .= ' <style type="text/css">
            #vidleft{ display:inline-block; float:left;}#tray{display:inline-block; float:right;height: 110px;}#container{width:773px;}</style><div id="container"><div id="vidleft"><object type="application/x-shockwave-flash" height="378px" width="620" id="live_embed_player_flash" '
        . 'data="http://www.twitch.tv/widgets/live_embed_player.swf?channel=' .$ign[0]. '" bgcolor="#000000">'
        . '<param name="allowFullScreen" value="true" />'
        . '<param name="allowScriptAccess" value="always" />'
        . '<param name="allowNetworking" value="all" />'
        . '<param name="movie" value="http://www.twitch.tv/widgets/live_embed_player.swf" />'
        . '<param name="flashvars" value="hostname=www.twitch.tv&channel=' .$ign[0]. '&auto_play=true&start_volume=25" />'
        . '</object></div>';

        $html2 .='<div id="vidright" style="width:140px;height:378px;display:inline-block;overflow-x:hidden;">';
        echo $html;
        echo $html2;
        for($y=1;$y<count($ign);$y++){
            $im = "img".strval($y);
            $sl = "slot".strval($y);
        echo '<div id="tray"><a id="slot'.$y.'" href="javascript:click(\''.$ign[$y].'\',\''.$im.'\',\''.$sl.'\')"><img id="img'.$y.'" src="http://static-cdn.jtvnw.net/previews-ttv/live_user_'.$ign[$y].'-150x126.jpg"></a></div>';
        }
    echo "</div></div>";
    ?>
        <script type='text/javascript'>
        var current1='<?php echo $ign[0];?>';
            function click(a,image,slot){
                // var numb=num.toString();
                var b=a;
                var c="<object type='application/x-shockwave-flash' height='378' width='620' id='live_embed_player_flash' data='http://www.twitch.tv/widgets/live_embed_player.swf?channel=";
                var d="' bgcolor='#000000'><param name='allowFullScreen' value='true' /><param name='allowScriptAccess' value='always' /><param name='allowNetworking' value='all' /><param name='movie' value='http://www.twitch.tv/widgets/live_embed_player.swf' /><param name='flashvars' value='hostname=www.twitch.tv&channel=";
                var e="&auto_play=true&start_volume=25' /></object><a href='http://www.twitch.tv/";
                var f="' class='trk' style='padding:2px 0px 4px; display:block; width:345px; font-weight:normal; font-size:10px; text-decoration:underline; text-align:center;'>Watch live video on www.twitch.tv</a>";
                var g="http://static-cdn.jtvnw.net/previews-ttv/live_user_";
                var h="-150x126.jpg";
                document.getElementById("vidleft").innerHTML=c+b+d+b+e+b+f;
                document.getElementById(image).src="http://static-cdn.jtvnw.net/previews-ttv/live_user_"+current1+"-150x126.jpg";
                document.getElementById(slot).href="javascript:click('"+current1+"','"+image+"','"+slot+"')";
                current1 = b;
            }
        </script>
    <?php
    }
    else if($playername=='youtube'){
        $j=0;
        $streams=array();
        $result2 = $wpdb->get_results("SELECT * from topplayerlist WHERE streamURI LIKE '%youtube.com%'");
        foreach ($result2 as $key2) {
                    if($key2->approved==1){
                        if($key2->streaming==1){
                            $str=explode("?v=",$key2->streamURI);
                            $streams[$j]=$str[1];
                        $j++;
                        }
                    }
        }
        
        $html .= ' <style type="text/css">
            #vidleft{ display:inline-block; float:left;}#tray{display:inline-block; float:right;height: 108px;}#container{width:763px;}</style><div id="container"><div id="vidleft"><iframe width="560" height="315" src="http://www.youtube.com/embed/'.$streams[0].'" frameborder="0" allowfullscreen></iframe></div>';
        echo $html;

        echo "<div id='vidright2' style='overflow-x:hidden;height:315px;'>";
        for($y=1;$y<count($streams);$y++){
            $im2 = "img".strval($y);
            $sl2 = "slot".strval($y);
        echo '<div id="tray"><a id="slot'.$y.'" href="javascript:clicky(\''.$streams[$y].'\',\''.$im2.'\',\''.$sl2.'\')">';
        getYoutubeImage("http://www.youtube.com/watch?v=$streams[$y]","$y");
        echo "</a></div>";
        }
        echo "</div></div>";
    }
    ?>

            <script type='text/javascript'>
        var current2='<?php echo $stream[0]; ?>';
            function clicky(a,image,slot){
                var b=a;
                var ytf='<iframe width="560" height="315" src="http://www.youtube.com/embed/';
                var ytf2='" frameborder="0" allowfullscreen></iframe>';
                document.getElementById("vidleft").innerHTML=ytf+b+ytf2;
                document.getElementById(image).src="http://i3.ytimg.com/vi/"+current2+"/default.jpg";
                document.getElementById(slot).href="javascript:clicky('"+current2+"','"+image+"','"+slot+"')";
                current2=b;
                
            }
        </script>

    <?php
    
}
function getYoutubeImage($e,$nr){
                        //GET THE URL
        $url = $e;
        $queryString = parse_url($url, PHP_URL_QUERY);
        parse_str($queryString, $params);
        $v = $params['v'];  
                        //DISPLAY THE IMAGE
        if(strlen($v)>0){
            echo "<img id='img".$nr."' src='http://i3.ytimg.com/vi/$v/mqdefault_v4574690.jpg' width='200px' height='99px'/>";
        }
    }
add_shortcode('westream','westreamplug');
?>